package com.android.attendance.activity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import com.example.androidattendancesystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.text.SimpleDateFormat;
import java.util.*;

public class AddAttandanceSessionActivity extends Activity {

    private Spinner spinnerDept, spinnerYear, spinnerSubject;
    private EditText dateEditText;
    private Button btnAddAttendance, btnViewAttendance, btnViewTotalAttendance;

    private DatabaseReference database;
    private FirebaseAuth mAuth;

    private String department, year, subject, date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_attandance);

        database = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        spinnerDept = findViewById(R.id.spinner1);
        spinnerYear = findViewById(R.id.spinneryear);
        spinnerSubject = findViewById(R.id.spinnerSE);
        dateEditText = findViewById(R.id.DateEditText);

        btnAddAttendance = findViewById(R.id.buttonsubmit);
        btnViewAttendance = findViewById(R.id.viewAttendancebutton);
        btnViewTotalAttendance = findViewById(R.id.viewTotalAttendanceButton);

        setupSpinners();
        setupDatePicker();

        btnAddAttendance.setOnClickListener(v -> createSession());

        // 🔥 View Attendance now opens session list
        btnViewAttendance.setOnClickListener(v -> {
            Intent intent = new Intent(
                    AddAttandanceSessionActivity.this,
                    FacultyReportsActivity.class
            );
            startActivity(intent);
        });

        btnViewTotalAttendance.setOnClickListener(v ->
                startActivity(new Intent(this, ViewTotalAttendanceActivity.class)));
    }

    private void setupSpinners() {

        spinnerDept.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"IT", "AIML"}
        ));

        spinnerYear.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1st Year", "2nd Year", "3rd Year", "4th Year"}
        ));

        spinnerSubject.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Java", "Android", "DBMS", "AI"}
        ));
    }

    private void setupDatePicker() {

        dateEditText.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            DatePickerDialog dialog = new DatePickerDialog(
                    this,
                    (view, year, month, dayOfMonth) -> {
                        String selectedDate =
                                dayOfMonth + "/" + (month + 1) + "/" + year;
                        dateEditText.setText(selectedDate);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            dialog.show();
        });
    }

    private void createSession() {

        department = spinnerDept.getSelectedItem().toString();
        year = spinnerYear.getSelectedItem().toString();
        subject = spinnerSubject.getSelectedItem().toString();
        date = dateEditText.getText().toString().trim();

        if (date.isEmpty()) {
            Toast.makeText(this, "Please select date", Toast.LENGTH_SHORT).show();
            return;
        }

        String facultyId = mAuth.getCurrentUser().getUid();

        String sessionId =
                database.child("attendanceSessions").push().getKey();

        String currentTime = new SimpleDateFormat(
                "hh:mm a",
                Locale.getDefault()
        ).format(new Date());

        Map<String, Object> sessionMap = new HashMap<>();
        sessionMap.put("facultyId", facultyId);
        sessionMap.put("department", department);
        sessionMap.put("year", year);
        sessionMap.put("subject", subject);
        sessionMap.put("date", date);
        sessionMap.put("time", currentTime);

        database.child("attendanceSessions")
                .child(sessionId)
                .setValue(sessionMap)
                .addOnSuccessListener(unused -> {

                    Toast.makeText(this,
                            "Session Created Successfully",
                            Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(
                            AddAttandanceSessionActivity.this,
                            FacultyMarkAttendanceActivity.class
                    );

                    intent.putExtra("sessionId", sessionId);
                    intent.putExtra("department", department);
                    intent.putExtra("year", year);

                    startActivity(intent);
                });
    }
}