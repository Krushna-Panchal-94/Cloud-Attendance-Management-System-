package com.android.attendance.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import com.example.androidattendancesystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

public class LoginActivity extends Activity {

	EditText editTextusername, editTextpassword;
	Spinner spinnerloginas;
	Button buttonlogin;

	FirebaseAuth mAuth;
	DatabaseReference database;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		editTextusername = findViewById(R.id.editTextusername);
		editTextpassword = findViewById(R.id.editTextpassword);
		spinnerloginas = findViewById(R.id.spinnerloginas);
		buttonlogin = findViewById(R.id.buttonlogin);

		mAuth = FirebaseAuth.getInstance();
		database = FirebaseDatabase.getInstance().getReference();

		ArrayAdapter<String> adapter = new ArrayAdapter<>(
				this,
				android.R.layout.simple_spinner_dropdown_item,
				new String[]{"Admin", "Faculty", "Student"}
		);
		spinnerloginas.setAdapter(adapter);

		buttonlogin.setOnClickListener(v -> loginUser());
	}

	private void loginUser() {

		String email = editTextusername.getText().toString();
		String password = editTextpassword.getText().toString();

		if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) return;
		if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
			editTextusername.setError("Enter valid email address");
			return;
		}

		mAuth.signInWithEmailAndPassword(email, password)
				.addOnSuccessListener(authResult -> {

					String uid = authResult.getUser().getUid();

					database.child("users").child(uid)
							.addListenerForSingleValueEvent(new ValueEventListener() {

								@Override
								public void onDataChange(DataSnapshot snapshot) {

									String role = snapshot.child("role").getValue(String.class);
									String selected = spinnerloginas.getSelectedItem().toString();

									if (role != null && role.equalsIgnoreCase(selected)) {

										if (role.equals("Admin"))
											startActivity(new Intent(LoginActivity.this, AdminDashboardActivity.class));
										else if (role.equals("Faculty"))
											startActivity(new Intent(LoginActivity.this, FacultyDashboardActivity.class));
										else
											startActivity(new Intent(LoginActivity.this, StudentDashboardActivity.class));

										finish();
									} else {
										Toast.makeText(LoginActivity.this, "Role mismatch", Toast.LENGTH_LONG).show();
									}
								}

								@Override
								public void onCancelled(DatabaseError error) {}
							});
				});
	}
}