package com.android.attendance.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;

import com.example.androidattendancesystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class FacultyReportsActivity extends Activity {

    private ListView listView;
    private DatabaseReference databaseReference;

    private ArrayList<String> sessionList;
    private ArrayList<String> sessionIds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendance_list_screen);

        listView = findViewById(R.id.listview);

        databaseReference = FirebaseDatabase.getInstance().getReference();

        sessionList = new ArrayList<>();
        sessionIds = new ArrayList<>();

        loadSessions();
    }

    private void loadSessions() {

        String facultyId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        databaseReference.child("attendanceSessions")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {

                        sessionList.clear();
                        sessionIds.clear();

                        for (DataSnapshot session : snapshot.getChildren()) {

                            String faculty = session.child("facultyId").getValue(String.class);

                            if (faculty != null && faculty.equals(facultyId)) {

                                String subject = session.child("subject").getValue(String.class);
                                String date = session.child("date").getValue(String.class);
                                String time = session.child("time").getValue(String.class);

                                sessionIds.add(session.getKey());

                                sessionList.add(
                                        subject + "\nDate: " + date + "\nTime: " + time
                                );
                            }
                        }

                        ArrayAdapter<String> adapter =
                                new ArrayAdapter<>(
                                        FacultyReportsActivity.this,
                                        android.R.layout.simple_list_item_1,
                                        sessionList
                                );

                        listView.setAdapter(adapter);

                        listView.setOnItemClickListener((parent, view, position, id) -> {

                            Intent intent = new Intent(
                                    FacultyReportsActivity.this,
                                    ViewAttendanceByFacultyActivity.class
                            );

                            intent.putExtra("sessionId", sessionIds.get(position));
                            startActivity(intent);
                        });
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {}
                });
    }
}