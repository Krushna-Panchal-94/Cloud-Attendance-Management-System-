package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidattendancesystem.R;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class ViewStudentActivity extends Activity {

	private Spinner spinnerBranch, spinnerYear;
	private Button submit;
	private RecyclerView recyclerView;

	private DatabaseReference databaseReference;
	private ArrayList<StudentModel> studentList;
	private StudentViewAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewstudent);

		spinnerBranch = findViewById(R.id.spinnerbranchView);
		spinnerYear = findViewById(R.id.spinneryearView);
		submit = findViewById(R.id.submitButton);
		recyclerView = findViewById(R.id.recyclerStudents);

		databaseReference = FirebaseDatabase.getInstance().getReference();

		studentList = new ArrayList<>();
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
		adapter = new StudentViewAdapter(this, studentList);
		recyclerView.setAdapter(adapter);

		setupSpinners();

		submit.setOnClickListener(v -> loadStudents());
	}

	private void setupSpinners() {

		ArrayAdapter<String> branchAdapter = new ArrayAdapter<>(
				this,
				android.R.layout.simple_spinner_dropdown_item,
				new String[]{"All", "IT", "AIML"}
		);
		spinnerBranch.setAdapter(branchAdapter);

		ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(
				this,
				android.R.layout.simple_spinner_dropdown_item,
				new String[]{"All", "1st Year", "2nd Year", "3rd Year", "4th Year"}
		);
		spinnerYear.setAdapter(yearAdapter);
	}

	private void loadStudents() {

		String selectedBranch = spinnerBranch.getSelectedItem().toString();
		String selectedYear = spinnerYear.getSelectedItem().toString();

		databaseReference.child("users")
				.addListenerForSingleValueEvent(new ValueEventListener() {

					@Override
					public void onDataChange(DataSnapshot snapshot) {

						studentList.clear();

						for (DataSnapshot data : snapshot.getChildren()) {

							String role = data.child("role")
									.getValue(String.class);

							if (role != null &&
									role.equalsIgnoreCase("student")) {

								String branch = data.child("department")
										.getValue(String.class);

								String year = data.child("year")
										.getValue(String.class);

								boolean branchMatch =
										selectedBranch.equals("All") ||
												(branch != null &&
														branch.equalsIgnoreCase(selectedBranch));

								boolean yearMatch =
										selectedYear.equals("All") ||
												(year != null &&
														year.equalsIgnoreCase(selectedYear));

								if (branchMatch && yearMatch) {

									// 🔥 SAFE NAME FETCH
									String name =
											data.child("firstName")
													.getValue(String.class);

									if (name == null) {
										name = data.child("firstname")
												.getValue(String.class);
									}

									if (name == null) {
										name = data.child("name")
												.getValue(String.class);
									}

									if (name == null) {
										name = "No Name";
									}

									String email =
											data.child("email")
													.getValue(String.class);

									StudentModel student =
											new StudentModel(
													data.getKey(),
													name,
													branch,
													year,
													email
											);

									studentList.add(student);
								}
							}
						}

						adapter.notifyDataSetChanged();

						if (studentList.isEmpty()) {
							Toast.makeText(
									ViewStudentActivity.this,
									"No Students Found",
									Toast.LENGTH_SHORT
							).show();
						}
					}

					@Override
					public void onCancelled(DatabaseError error) {

						Toast.makeText(
								ViewStudentActivity.this,
								"Failed to load students",
								Toast.LENGTH_SHORT
						).show();
					}
				});
	}
}