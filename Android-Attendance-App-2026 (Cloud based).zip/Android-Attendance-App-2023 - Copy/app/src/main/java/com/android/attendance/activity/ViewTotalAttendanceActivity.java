package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidattendancesystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class ViewTotalAttendanceActivity extends Activity {

    private ListView listView;
    private DatabaseReference databaseReference;
    private ArrayList<String> totalList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attendance_list_screen);

        listView = findViewById(R.id.listview);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        totalList = new ArrayList<>();

        loadAllSessions();
    }

    private void loadAllSessions() {

        String facultyId =
                FirebaseAuth.getInstance().getCurrentUser().getUid();

        databaseReference.child("attendanceSessions")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {

                        totalList.clear();

                        for (DataSnapshot session : snapshot.getChildren()) {

                            String faculty =
                                    session.child("facultyId")
                                            .getValue(String.class);

                            String date =
                                    session.child("date")
                                            .getValue(String.class);

                            String time =
                                    session.child("time")
                                            .getValue(String.class);

                            if (faculty != null &&
                                    faculty.equals(facultyId)) {

                                String sessionId = session.getKey();

                                loadSessionSummary(sessionId, date, time);
                            }
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {}
                });
    }

    private void loadSessionSummary(String sessionId,
                                    String date,
                                    String time) {

        databaseReference.child("attendance")
                .child(sessionId)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {

                        int presentCount = 0;
                        int totalCount = 0;

                        for (DataSnapshot student : snapshot.getChildren()) {

                            totalCount++;

                            Boolean present =
                                    student.getValue(Boolean.class);

                            if (present != null && present)
                                presentCount++;
                        }

                        totalList.add("Date: " + date);
                        totalList.add("Time: " + time);
                        totalList.add("Present: " + presentCount);
                        totalList.add("Total Students: " + totalCount);
                        totalList.add("------------------------");

                        ArrayAdapter<String> adapter =
                                new ArrayAdapter<>(
                                        ViewTotalAttendanceActivity.this,
                                        android.R.layout.simple_list_item_1,
                                        totalList);

                        listView.setAdapter(adapter);
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {}
                });
    }
}