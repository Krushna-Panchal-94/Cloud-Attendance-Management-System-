package com.android.attendance.activity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidattendancesystem.R;

import java.util.ArrayList;

public class StudentViewAdapter extends RecyclerView.Adapter<StudentViewAdapter.ViewHolder> {

    private Context context;
    private ArrayList<StudentModel> studentList;

    public StudentViewAdapter(Context context, ArrayList<StudentModel> studentList) {
        this.context = context;
        this.studentList = studentList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_student_view, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        StudentModel student = studentList.get(position);

        holder.textName.setText("Name: " + student.getFirstName());
        holder.textDept.setText("Department: " + student.getDepartment());
        holder.textYear.setText("Year: " + student.getYear());
        holder.textEmail.setText("Email: " + student.getEmail());
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView textName, textDept, textYear, textEmail;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textName = itemView.findViewById(R.id.textName);
            textDept = itemView.findViewById(R.id.textDept);
            textYear = itemView.findViewById(R.id.textYear);
            textEmail = itemView.findViewById(R.id.textEmail);
        }
    }
}