package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.util.Log;

import com.example.androidattendancesystem.R;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class ViewAttendanceByFacultyActivity extends Activity {

	private ListView listView;
	private ToggleButton toggleAttendance;

	private DatabaseReference databaseReference;
	private ArrayList<String> attendanceList;
	private ArrayAdapter<String> adapter;

	private String sessionId;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.attendance_list_screen);

		listView = findViewById(R.id.listview);
		toggleAttendance = findViewById(R.id.toggleAttendance);

		databaseReference = FirebaseDatabase.getInstance().getReference();
		attendanceList = new ArrayList<>();

		adapter = new ArrayAdapter<>(
				this,
				android.R.layout.simple_list_item_1,
				attendanceList
		);

		listView.setAdapter(adapter);

		sessionId = getIntent().getStringExtra("sessionId");

		if (sessionId == null) {
			Toast.makeText(this, "Session not found", Toast.LENGTH_SHORT).show();
			finish();
			return;
		}

		// Default → Show Present Students
		toggleAttendance.setChecked(false);
		loadAttendance(false);

		toggleAttendance.setOnCheckedChangeListener((buttonView, isChecked) -> {
			loadAttendance(isChecked);
		});
	}

	// isChecked = true → Show Absent
	// isChecked = false → Show Present
	private void loadAttendance(boolean showAbsent) {

		attendanceList.clear();
		adapter.notifyDataSetChanged();

		databaseReference.child("attendance")
				.child(sessionId)
				.addListenerForSingleValueEvent(new ValueEventListener() {

					@Override
					public void onDataChange(DataSnapshot snapshot) {

						if (!snapshot.exists()) {
							Toast.makeText(
									ViewAttendanceByFacultyActivity.this,
									"No attendance recorded",
									Toast.LENGTH_SHORT
							).show();
							return;
						}

						for (DataSnapshot studentSnap : snapshot.getChildren()) {

							String uid = studentSnap.getKey();
							Boolean present = studentSnap.getValue(Boolean.class);

							if (present == null) continue;

							// 🔥 SHOW PRESENT
							if (!showAbsent && present) {
								fetchStudentName(uid);
							}

							// 🔥 SHOW ABSENT
							if (showAbsent && !present) {
								fetchStudentName(uid);
							}
						}
					}

					@Override
					public void onCancelled(DatabaseError error) {}
				});
	}

	private void fetchStudentName(String uid) {

		databaseReference.child("users")
				.child(uid)
				.addListenerForSingleValueEvent(new ValueEventListener() {

					@Override
					public void onDataChange(DataSnapshot snapshot) {

						if (!snapshot.exists()) return;

						String rollNo = snapshot.child("rollNo")
								.getValue(String.class);

						String firstName = snapshot.child("firstName")
								.getValue(String.class);

						String lastName = snapshot.child("lastName")
								.getValue(String.class);

						if (rollNo == null) rollNo = "";
						if (firstName == null) firstName = "";
						if (lastName == null) lastName = "";

						String fullName =
								rollNo + " - " + firstName + " " + lastName;

						attendanceList.add(fullName);
						adapter.notifyDataSetChanged();
					}

					@Override
					public void onCancelled(DatabaseError error) {}
				});
	}
}