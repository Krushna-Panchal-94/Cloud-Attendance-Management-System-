package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.androidattendancesystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class AddFacultyActivity extends Activity {

	private EditText editTextFirstName;
	private EditText editTextLastName;
	private EditText editTextEmail;
	private Button registerButton;

	private FirebaseAuth mAuth;
	private DatabaseReference database;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addfaculty);  // MUST match XML file name

		editTextFirstName = findViewById(R.id.editTextFirstName);
		editTextLastName = findViewById(R.id.editTextLastName);
		editTextEmail = findViewById(R.id.editTextUserName);
		registerButton = findViewById(R.id.RegisterButton);

		mAuth = FirebaseAuth.getInstance();
		database = FirebaseDatabase.getInstance().getReference();

		registerButton.setOnClickListener(v -> registerFaculty());
	}

	private void registerFaculty() {

		String firstName = editTextFirstName.getText().toString().trim();
		String lastName = editTextLastName.getText().toString().trim();
		String email = editTextEmail.getText().toString().trim();

		if (TextUtils.isEmpty(firstName)) {
			editTextFirstName.setError("Enter First Name");
			return;
		}

		if (TextUtils.isEmpty(email)) {
			editTextEmail.setError("Enter Email");
			return;
		}

		String password = "pass123";

		mAuth.createUserWithEmailAndPassword(email, password)
				.addOnSuccessListener(authResult -> {

					String uid = authResult.getUser().getUid();

					Map<String, Object> facultyMap = new HashMap<>();
					facultyMap.put("role", "Faculty");
					facultyMap.put("firstName", firstName);
					facultyMap.put("lastName", lastName);
					facultyMap.put("email", email);

					database.child("users").child(uid).setValue(facultyMap);

					Toast.makeText(this, "Faculty Added Successfully", Toast.LENGTH_LONG).show();
				})
				.addOnFailureListener(e ->
						Toast.makeText(this,
								"Error: " + e.getMessage(),
								Toast.LENGTH_LONG).show());
	}
}