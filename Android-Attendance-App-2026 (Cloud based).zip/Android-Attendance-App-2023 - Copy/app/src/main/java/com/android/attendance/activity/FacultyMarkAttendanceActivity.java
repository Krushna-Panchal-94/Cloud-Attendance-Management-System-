package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidattendancesystem.R;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FacultyMarkAttendanceActivity extends Activity {

    private RecyclerView recyclerStudents;
    private Button buttonSubmitAll;

    private DatabaseReference databaseReference;
    private ArrayList<StudentModel> studentList;
    private StudentAttendanceAdapter adapter;

    private String sessionId, department, year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_mark_attendance);

        recyclerStudents = findViewById(R.id.recyclerStudents);
        buttonSubmitAll = findViewById(R.id.btnSubmitAll);

        databaseReference = FirebaseDatabase.getInstance().getReference();
        studentList = new ArrayList<>();

        recyclerStudents.setLayoutManager(new LinearLayoutManager(this));
        adapter = new StudentAttendanceAdapter(this, studentList);
        recyclerStudents.setAdapter(adapter);

        sessionId = getIntent().getStringExtra("sessionId");
        department = getIntent().getStringExtra("department");
        year = getIntent().getStringExtra("year");

        loadStudents();

        buttonSubmitAll.setOnClickListener(v -> submitAttendance());
    }

    private void loadStudents() {

        databaseReference.child("users")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {

                        studentList.clear();

                        for (DataSnapshot data : snapshot.getChildren()) {

                            String role = data.child("role").getValue(String.class);
                            String dept = data.child("department").getValue(String.class);
                            String yr = data.child("year").getValue(String.class);

                            if (role != null &&
                                    role.equalsIgnoreCase("student") &&
                                    dept != null &&
                                    yr != null &&
                                    dept.equalsIgnoreCase(department) &&
                                    yr.equalsIgnoreCase(year)) {

                                String uid = data.getKey();
                                String name = data.child("firstName").getValue(String.class);
                                String email = data.child("email").getValue(String.class);

                                studentList.add(
                                        new StudentModel(uid, name, dept, yr, email)
                                );
                            }
                        }

                        adapter.notifyDataSetChanged();
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {}
                });
    }

    private void submitAttendance() {

        Map<String, Object> attendanceMap = new HashMap<>();

        for (StudentModel student : studentList) {
            attendanceMap.put(student.getUid(), student.isPresent());
        }

        databaseReference.child("attendance")
                .child(sessionId)
                .setValue(attendanceMap)
                .addOnSuccessListener(unused ->
                        Toast.makeText(this,
                                "Attendance Submitted Successfully",
                                Toast.LENGTH_LONG).show());
    }
}