package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import com.example.androidattendancesystem.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class AdminCreateSessionActivity extends Activity {

    EditText editSubject;
    Button createButton;

    DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_session);

        editSubject = findViewById(R.id.editSubject);
        createButton = findViewById(R.id.buttonCreate);

        database = FirebaseDatabase.getInstance().getReference();

        createButton.setOnClickListener(v -> createSession());
    }

    private void createSession() {

        String subject = editSubject.getText().toString();
        String facultyId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        String sessionId = database.child("sessions").push().getKey();

        String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());

        Map<String, Object> sessionMap = new HashMap<>();
        sessionMap.put("subject", subject);
        sessionMap.put("date", date);
        sessionMap.put("facultyId", facultyId);

        database.child("sessions").child(sessionId).setValue(sessionMap);

        Toast.makeText(this, "Session Created", Toast.LENGTH_LONG).show();
    }
}