package com.android.attendance.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.androidattendancesystem.R;

public class FacultyDashboardActivity extends Activity {

    Button createSessionButton;
    Button viewReportsButton;
    Button logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_faculty_dashboard);

        createSessionButton = findViewById(R.id.buttonCreateSession);
        viewReportsButton = findViewById(R.id.buttonViewReports);
        logoutButton = findViewById(R.id.buttonFacultyLogout);

        // ================= CREATE SESSION =================
        createSessionButton.setOnClickListener(v -> {
            Intent intent = new Intent(FacultyDashboardActivity.this,
                    AddAttandanceSessionActivity.class);
            startActivity(intent);
        });

        // ================= VIEW REPORTS =================
        viewReportsButton.setOnClickListener(v -> {

            Intent intent = new Intent(
                    FacultyDashboardActivity.this,
                    FacultyReportsActivity.class);

            startActivity(intent);
        });

        // ================= LOGOUT =================
        logoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(FacultyDashboardActivity.this,
                    LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }
}