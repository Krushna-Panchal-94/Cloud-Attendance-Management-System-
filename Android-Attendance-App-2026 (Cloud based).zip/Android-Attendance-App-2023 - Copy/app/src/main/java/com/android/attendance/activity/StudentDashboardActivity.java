package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidattendancesystem.R;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class StudentDashboardActivity extends Activity {

    private PieChart pieChart;
    private TextView textPercentage;

    private DatabaseReference database;
    private String studentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_dashboard);

        pieChart = findViewById(R.id.piechart);
        textPercentage = findViewById(R.id.textPercentage);

        database = FirebaseDatabase.getInstance().getReference();
        studentId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        calculateAttendance();
    }

    private void calculateAttendance() {

        database.child("attendance")
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    int totalSessions = 0;
                    int presentCount = 0;

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {

                        for (DataSnapshot session : snapshot.getChildren()) {

                            totalSessions++;

                            Boolean present =
                                    session.child(studentId)
                                            .getValue(Boolean.class);

                            if (present != null && present) {
                                presentCount++;
                            }
                        }

                        if (totalSessions > 0) {

                            double percentage =
                                    (presentCount * 100.0) / totalSessions;

                            textPercentage.setText(
                                    "Attendance: " +
                                            String.format("%.2f", percentage) + "%"
                            );

                            showPieChart(presentCount,
                                    totalSessions - presentCount);

                        } else {

                            textPercentage.setText("No attendance records");

                            showPieChart(0, 1);
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {}
                });
    }

    private void showPieChart(int present, int absent) {

        ArrayList<PieEntry> entries = new ArrayList<>();

        entries.add(new PieEntry(present, "Present"));
        entries.add(new PieEntry(absent, "Absent"));

        PieDataSet dataSet = new PieDataSet(entries, "Attendance");

        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextSize(14f);

        PieData data = new PieData(dataSet);

        pieChart.setData(data);
        pieChart.setUsePercentValues(true);
        pieChart.setEntryLabelTextSize(14f);
        pieChart.getDescription().setEnabled(false);
        pieChart.animateY(1000);

        pieChart.invalidate();   // VERY IMPORTANT
    }
}