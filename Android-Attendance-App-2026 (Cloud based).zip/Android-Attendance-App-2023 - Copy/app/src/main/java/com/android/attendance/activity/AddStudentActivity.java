package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;
import com.example.androidattendancesystem.R;
import com.google.firebase.auth.*;
import com.google.firebase.database.*;

import java.util.HashMap;
import java.util.Map;

public class AddStudentActivity extends Activity {

	EditText textRollNo, textFirstName, textLastName, textEmail;
	Spinner spinnerDept, spinnerYear;
	Button registerButton;

	FirebaseAuth mAuth;
	DatabaseReference database;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addstudent);

		textRollNo = findViewById(R.id.editTextRollNo);
		textFirstName = findViewById(R.id.editTextFirstName);
		textLastName = findViewById(R.id.editTextLastName);
		textEmail = findViewById(R.id.editTextEmail);
		spinnerDept = findViewById(R.id.spinnerdept);
		spinnerYear = findViewById(R.id.spinneryear);
		registerButton = findViewById(R.id.RegisterButton);

		mAuth = FirebaseAuth.getInstance();
		database = FirebaseDatabase.getInstance().getReference();

		ArrayAdapter<String> deptAdapter = new ArrayAdapter<>(
				this,
				android.R.layout.simple_spinner_dropdown_item,
				new String[]{"IT", "AIML"}
		);
		spinnerDept.setAdapter(deptAdapter);

		ArrayAdapter<String> yearAdapter = new ArrayAdapter<>(
				this,
				android.R.layout.simple_spinner_dropdown_item,
				new String[]{"1st Year", "2nd Year", "3rd Year", "4th Year"}
		);
		spinnerYear.setAdapter(yearAdapter);

		registerButton.setOnClickListener(v -> registerStudent());
	}

	private void registerStudent() {

		String rollNo = textRollNo.getText().toString().trim();
		String firstName = textFirstName.getText().toString().trim();
		String lastName = textLastName.getText().toString().trim();
		String email = textEmail.getText().toString().trim();
		String password = "pass123";

		if (TextUtils.isEmpty(rollNo)) {
			textRollNo.setError("Enter Roll Number");
			return;
		}

		if (TextUtils.isEmpty(email)) {
			textEmail.setError("Enter Email");
			return;
		}

		// 🔥 STEP 1: Check if roll number already exists
		database.child("users")
				.orderByChild("rollNo")
				.equalTo(rollNo)
				.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot snapshot) {

						if (snapshot.exists()) {

							Toast.makeText(AddStudentActivity.this,
									"Roll Number already registered",
									Toast.LENGTH_LONG).show();

						} else {

							// 🔥 STEP 2: Register with Firebase Auth
							mAuth.createUserWithEmailAndPassword(email, password)
									.addOnCompleteListener(task -> {

										if (task.isSuccessful()) {

											String uid = task.getResult().getUser().getUid();

											Map<String, Object> studentMap = new HashMap<>();
											studentMap.put("role", "student");
											studentMap.put("rollNo", rollNo);
											studentMap.put("firstName", firstName);
											studentMap.put("lastName", lastName);
											studentMap.put("department", spinnerDept.getSelectedItem().toString());
											studentMap.put("year", spinnerYear.getSelectedItem().toString());
											studentMap.put("email", email);

											database.child("users")
													.child(uid)
													.setValue(studentMap);

											Toast.makeText(AddStudentActivity.this,
													"Student Registered Successfully",
													Toast.LENGTH_LONG).show();

										} else {

											Exception e = task.getException();

											if (e instanceof FirebaseAuthUserCollisionException) {

												Toast.makeText(AddStudentActivity.this,
														email + " is already registered",
														Toast.LENGTH_LONG).show();

											} else {

												Toast.makeText(AddStudentActivity.this,
														"Error: " + e.getMessage(),
														Toast.LENGTH_LONG).show();
											}
										}
									});
						}
					}

					@Override
					public void onCancelled(DatabaseError error) {
						Toast.makeText(AddStudentActivity.this,
								"Database Error",
								Toast.LENGTH_SHORT).show();
					}
				});
	}
}