package com.android.attendance.activity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.androidattendancesystem.R;

import java.util.ArrayList;

public class StudentAttendanceAdapter extends RecyclerView.Adapter<StudentAttendanceAdapter.ViewHolder> {

    private Context context;
    private ArrayList<StudentModel> studentList;

    public StudentAttendanceAdapter(Context context, ArrayList<StudentModel> studentList) {
        this.context = context;
        this.studentList = studentList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_student_checkbox, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        StudentModel student = studentList.get(position);

        // Show student name
        holder.textStudentName.setText(student.getFirstName());

        // Prevent recycling bug
        holder.checkBoxPresent.setOnCheckedChangeListener(null);
        holder.checkBoxPresent.setChecked(student.isPresent());

        holder.checkBoxPresent.setOnCheckedChangeListener((buttonView, isChecked) -> {
            student.setPresent(isChecked);
        });
    }

    @Override
    public int getItemCount() {
        return studentList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        CheckBox checkBoxPresent;
        TextView textStudentName;

        public ViewHolder(View itemView) {
            super(itemView);

            checkBoxPresent = itemView.findViewById(R.id.checkBoxPresent);
            textStudentName = itemView.findViewById(R.id.textStudentName);
        }
    }
}