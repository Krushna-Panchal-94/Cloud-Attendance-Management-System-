package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.androidattendancesystem.R;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class ViewFacultyActivity extends Activity {

	private ListView listView;
	private ArrayList<String> facultyList;
	private ArrayAdapter<String> adapter;

	private DatabaseReference databaseReference;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_faculty_list);

		listView = findViewById(R.id.listviewFaculty);

		facultyList = new ArrayList<>();
		adapter = new ArrayAdapter<>(this,
				android.R.layout.simple_list_item_1,
				facultyList);

		listView.setAdapter(adapter);

		databaseReference = FirebaseDatabase.getInstance().getReference();

		loadFaculty();
	}

	private void loadFaculty() {

		databaseReference.child("users")
				.addListenerForSingleValueEvent(new ValueEventListener() {

					@Override
					public void onDataChange(DataSnapshot snapshot) {

						facultyList.clear();

						for (DataSnapshot data : snapshot.getChildren()) {

							String role = data.child("role").getValue(String.class);

							if (role != null && role.equals("Faculty")) {

								String firstName = data.child("firstName").getValue(String.class);
								String lastName = data.child("lastName").getValue(String.class);

								String faculty = "First Name: " + firstName +
										"\nLast Name: " + lastName;

								facultyList.add(faculty);
							}
						}

						adapter.notifyDataSetChanged();
					}

					@Override
					public void onCancelled(DatabaseError error) {
						Toast.makeText(ViewFacultyActivity.this,
								"Failed to load faculty",
								Toast.LENGTH_SHORT).show();
					}
				});
	}
}