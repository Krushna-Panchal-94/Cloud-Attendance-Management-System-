package com.android.attendance.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.androidattendancesystem.R;

public class AdminDashboardActivity extends Activity {

    Button addStudent, viewStudent, addFaculty, viewFaculty, logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        addStudent = findViewById(R.id.buttonAddStudent);
        viewStudent = findViewById(R.id.buttonViewStudent);
        addFaculty = findViewById(R.id.buttonAddFaculty);
        viewFaculty = findViewById(R.id.buttonViewFaculty);
        logout = findViewById(R.id.buttonLogout);

        addStudent.setOnClickListener(v ->
                startActivity(new Intent(this, AddStudentActivity.class)));

        viewStudent.setOnClickListener(v ->
                startActivity(new Intent(this, ViewStudentActivity.class)));

        addFaculty.setOnClickListener(v ->
                startActivity(new Intent(this, AddFacultyActivity.class)));

        viewFaculty.setOnClickListener(v ->
                startActivity(new Intent(this, ViewFacultyActivity.class)));

        logout.setOnClickListener(v -> {
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }
}