package com.android.attendance.util;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSender {

    private static final String SENDER_EMAIL = "durgeshrathod7020697120@gmail.com";
    private static final String SENDER_PASSWORD = "owcamewfdmrsezph";

    public static void sendEmail(String recipientEmail,
                                 String subject,
                                 String messageBody) {

        new Thread(() -> {

            try {

                Properties props = new Properties();
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", "smtp.gmail.com");
                props.put("mail.smtp.port", "587");

                Session session = Session.getInstance(props,
                        new Authenticator() {
                            protected PasswordAuthentication
                            getPasswordAuthentication() {
                                return new PasswordAuthentication(
                                        SENDER_EMAIL,
                                        SENDER_PASSWORD
                                );
                            }
                        });

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress(SENDER_EMAIL));
                message.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse(recipientEmail));
                message.setSubject(subject);
                message.setText(messageBody);

                Transport.send(message);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }).start();
    }
}