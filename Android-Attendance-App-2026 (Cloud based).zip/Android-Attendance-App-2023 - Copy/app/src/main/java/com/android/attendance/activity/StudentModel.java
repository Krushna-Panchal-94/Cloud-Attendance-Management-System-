package com.android.attendance.activity;

public class StudentModel {

    private String uid;
    private String firstName;
    private String department;
    private String year;
    private String email;
    private boolean present;

    public StudentModel() {
        // Required empty constructor for Firebase
    }

    public StudentModel(String uid, String firstName,
                        String department, String year, String email) {
        this.uid = uid;
        this.firstName = firstName;
        this.department = department;
        this.year = year;
        this.email = email;
        this.present = false;
    }

    public String getUid() {
        return uid;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getDepartment() {
        return department;
    }

    public String getYear() {
        return year;
    }

    public String getEmail() {
        return email;
    }

    public boolean isPresent() {
        return present;
    }

    public void setPresent(boolean present) {
        this.present = present;
    }
}