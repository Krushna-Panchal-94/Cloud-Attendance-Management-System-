package com.android.attendance.activity;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.example.androidattendancesystem.R;
import com.google.firebase.database.*;

import java.util.ArrayList;

public class AddAttendanceActivity extends Activity {

	private ListView listView;
	private ArrayList<StudentModel> studentList;
	private ArrayAdapter<String> adapter;

	private DatabaseReference database;

	private String sessionId, department, year;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.__listview_main);

		listView = findViewById(R.id.listview);

		database = FirebaseDatabase.getInstance().getReference();

		sessionId = getIntent().getStringExtra("sessionId");
		department = getIntent().getStringExtra("department");
		year = getIntent().getStringExtra("year");

		studentList = new ArrayList<>();

		loadStudents();
	}

	private void loadStudents() {

		database.child("users")
				.addListenerForSingleValueEvent(new ValueEventListener() {

					@Override
					public void onDataChange(DataSnapshot snapshot) {

						ArrayList<String> names = new ArrayList<>();
						studentList.clear();

						for (DataSnapshot data : snapshot.getChildren()) {

							String role = data.child("role").getValue(String.class);
							String dept = data.child("department").getValue(String.class);
							String yr = data.child("year").getValue(String.class);

							if (role != null &&
									role.equalsIgnoreCase("student") &&
									dept.equalsIgnoreCase(department) &&
									yr.equalsIgnoreCase(year)) {

								StudentModel student = new StudentModel(
										data.getKey(),
										data.child("firstName").getValue(String.class),
										dept,
										yr,
										data.child("email").getValue(String.class)
								);

								studentList.add(student);
								names.add(student.getFirstName());
							}
						}

						adapter = new ArrayAdapter<>(
								AddAttendanceActivity.this,
								android.R.layout.simple_list_item_1,
								names
						);

						listView.setAdapter(adapter);

						listView.setOnItemClickListener((parent, view, position, id) -> {

							StudentModel student = studentList.get(position);

							saveAttendance(student.getUid(), true);

							Toast.makeText(
									AddAttendanceActivity.this,
									"Marked Present: " + student.getFirstName(),
									Toast.LENGTH_SHORT
							).show();
						});
					}

					@Override
					public void onCancelled(DatabaseError error) {}
				});
	}

	private void saveAttendance(String studentUid, boolean present) {

		database.child("attendance")
				.child(sessionId)
				.child(studentUid)
				.child("present")
				.setValue(present);
	}
}